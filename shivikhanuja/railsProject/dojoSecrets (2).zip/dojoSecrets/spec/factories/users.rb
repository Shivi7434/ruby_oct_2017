FactoryGirl.define do
  factory :user do
    first_name "Homer"
    last_name "Simpson"
    email "DONUTS@mmm.com"
    password "password"
  end
end
