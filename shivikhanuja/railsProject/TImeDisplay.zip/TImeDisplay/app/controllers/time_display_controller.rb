class TimeDisplayController < ApplicationController
    def time 
      @time = Time.new    
    end    
end
