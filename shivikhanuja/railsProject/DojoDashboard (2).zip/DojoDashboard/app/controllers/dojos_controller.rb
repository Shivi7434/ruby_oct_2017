class DojosController < ApplicationController
    def index
        @dojos = Dojo.all
    end    
    def new

    end
    def create
        @dojos = Dojo.new(dojo_params)
        
        if @dojos.valid?
            @dojos.save

            return redirect_to root_path
        end

        return redirect_to :back 
    end    
    private
    def dojo_params
        params.require(:dojo).permit(:branch, :street, :city, :state)
    end
end
