module AttendsHelper
end
